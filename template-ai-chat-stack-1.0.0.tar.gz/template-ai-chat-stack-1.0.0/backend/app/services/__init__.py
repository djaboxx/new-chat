"""
Services module initialization
"""
