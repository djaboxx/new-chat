"""
Models module initialization
"""
