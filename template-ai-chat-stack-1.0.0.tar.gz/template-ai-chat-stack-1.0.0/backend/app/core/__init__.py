"""
Core module initialization
"""
