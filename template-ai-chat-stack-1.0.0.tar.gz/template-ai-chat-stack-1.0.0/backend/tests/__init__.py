"""
Tests package initialization
"""
